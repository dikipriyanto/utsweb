<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Document</title>
</head>
<body>
    <div class="container">
        <label for=""> Pilih Kelas :</label>
        <table>
            
            <tr>
                <td style="width : 200px">Kelas A</td>
                <td><button class="btn btn-primary btn-xs" onclick="window.location.href='index.php?page=kelasA'">Pilih</button></td>
            </tr>
            <tr>
                <td>Kelas B</td>
                <td><button class="btn btn-primary btn-xs" onclick="window.location.href='index.php?page=kelasB'">Pilih</button></td>
            </tr>
            <tr>
                <td>Kelas C</td>
                <td><button class="btn btn-primary btn-xs" onclick="window.location.href='index.php?page=kelasC'">Pilih</button></td>
            </tr>
            <tr>
                <td>Kelas D</td>
                <td><button class="btn btn-primary btn-xs" onclick="window.location.href='index.php?page=kelasD'">Pilih</button></td>
            </tr>
            
        </table>
    </div>
    
</body>
</html>